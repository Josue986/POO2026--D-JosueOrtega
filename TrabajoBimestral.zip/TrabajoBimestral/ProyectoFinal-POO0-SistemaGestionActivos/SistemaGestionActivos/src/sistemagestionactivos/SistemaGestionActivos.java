package sistemagestionactivos;

public class SistemaGestionActivos {

    public static void main(String[] args) {


    }
    
}
